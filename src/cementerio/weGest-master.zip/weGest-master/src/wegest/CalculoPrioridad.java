package wegest;

public interface CalculoPrioridad {
	
	public long calcularPrioridad(String fecha);

}
